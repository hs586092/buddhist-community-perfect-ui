import{r,g as t}from"./vendor-DJG_os-6.js";var a=r();const o=t(a);export{o as R};
//# sourceMappingURL=router-BWvMR0q9.js.map
